public interface Searcher {
    int Search(int[] arr, int value);
}
