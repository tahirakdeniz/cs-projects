public interface Sorter {
    void sort(int[] arr);
    String getName();
}
